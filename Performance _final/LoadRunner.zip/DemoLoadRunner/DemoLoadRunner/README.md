# DemoLoadRunner – JPetStore Performance Testing

A LoadRunner Web HTTP/HTML performance-testing project for the JPetStore demo application.

## Project overview

The script models a realistic JPetStore user journey from application launch through product selection, cart, checkout, login, and order submission.

### Tools
- OpenText/Micro Focus LoadRunner VuGen 2022-compatible script
- Web – HTTP/HTML protocol
- C scripting

## Test flow

1. Launch JPetStore
2. Open the Dogs category
3. Select product K9-BD-01
4. Select item EST-6
5. Add item to cart
6. Proceed to checkout
7. Sign in with parameterized test credentials
8. Submit billing/order information
9. Confirm the order

## LoadRunner concepts demonstrated

- Transactions and response-time measurement
- Parameterization
- Regular-expression correlation
- Think time
- HTTP GET requests
- HTTP POST requests
- Dynamic URL handling
- Replay/result artifacts

## Correlation

The main `Action.c` captures dynamic values before they are reused:

- `C_category` – category identifier
- `C_productid` – product identifier
- `C_itemid` – item identifier

These values are then passed into later requests instead of hard-coding the recorded IDs.

## Repository structure

```text
DemoLoadRunner/
├── Action.c
├── vuser_init.c
├── vuser_end.c
├── globals.h
├── WebSocketBuffer.h
├── DemoLoadRunner.usr
├── DemoLoadRunner.prm
├── default.cfg
├── default.usp
├── LoginCredentials.dat
├── TestPaymentData.dat
├── data/                    # LoadRunner recording/runtime support data
├── result1/                 # Captured replay result and detailed snapshots
├── Generated/               # Selected generated artifacts retained for reference
└── Documentation/           # Project notes and replay observations
```

## Opening the script

Open `DemoLoadRunner.usr` in LoadRunner VuGen. The project was kept in a LoadRunner-compatible layout; the internal `data` and `result1` directories were intentionally not flattened or renamed.

The parameter configuration is in `DemoLoadRunner.prm`. The login table is `LoginCredentials.dat` and the payment test data is `TestPaymentData.dat`.

## Captured replay

The `result1` directory contains the captured replay generated from the original script. The recorded summary reports **11 passed steps and 0 failed steps** for the Action iteration. The result also contains a recorder-generated WebSocket step marked as a creation warning in the detailed report; it is retained because this repository preserves the original replay evidence.

## Important note

The credentials and payment values in the parameter files are **demo/test data only**. Replace them with appropriate test data when running against another environment. Do not commit real passwords, payment-card data, tokens, or production credentials.

## GitHub

The included `.gitignore` prevents common LoadRunner logs, temporary files, local metadata, and future replay output from being accidentally committed. The existing `result1` replay is explicitly retained as project evidence.
