# GitHub checklist

- [x] LoadRunner core files retained
- [x] Parameter configuration retained
- [x] Correlation code retained
- [x] Captured replay retained
- [x] README added
- [x] `.gitignore` added
- [x] Obsolete backup/compiler cache files removed
- [x] Machine-specific result metadata sanitized
- [x] Personal local path references removed from published metadata
