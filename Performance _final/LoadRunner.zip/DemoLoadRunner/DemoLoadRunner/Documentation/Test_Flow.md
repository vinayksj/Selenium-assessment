# Test Flow

## Business flow

`Launch → Category → Product → Item → Add to Cart → Checkout → Login → Continue Order → Confirm`

## Transactions

| Transaction | Purpose |
|---|---|
| `1_launchurl` | Launch application |
| `2_category` | Open Dogs category |
| `3_productid` | Open selected product |
| `4_itemid` | Open selected item |
| `5_addtocrt` | Add item to cart |
| `6_checkout` | Open checkout |
| `7_login` | Submit login credentials |
| `8_continue` | Submit billing/order details |
| `9_confirm` | Submit order confirmation |

## Correlation chain

`C_category` → `C_productid` → `C_itemid`

The correlated values are extracted from server responses and reused in subsequent URLs.
